export interface IPizzaToppingDetailsDto {
    ingredientName: string;
    price: number;
}

export interface IPizzaCrustDetailsDto {
    size: string;
    price: number;
}

export interface IPizzaSauceDetailsDto {
    name: string;
    price: number;
}

export interface ICheeseDetailsDto {
    isExtraCheeseRequired: boolean;
    price: number;
}
