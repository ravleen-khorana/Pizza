import { OtherItemsDto } from './other-items.dto';
import { IPizzaDetailsDto } from './pizza-details.dto';

export interface IMenuDetailsDto {
    id: number;
    name: string;
    type: string;
    imageUrl: string;
    pizzaDetails: IPizzaDetailsDto;
    otherItemDetails: OtherItemsDto;
    totalPrice?: number;
}
