import { ICheeseDetailsDto, IPizzaCrustDetailsDto, IPizzaSauceDetailsDto, IPizzaToppingDetailsDto } from './pizza-ingredients-details.dto';

export interface IPizzaDetailsDto {
    crust: IPizzaCrustDetailsDto;
    toppings: IPizzaToppingDetailsDto[];
    sauce: IPizzaSauceDetailsDto;
    cheese: ICheeseDetailsDto;
}
