
export interface OtherItemsDto {
    price: number;
    description: string;
}
