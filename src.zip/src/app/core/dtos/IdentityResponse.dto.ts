export interface IdentityResponse {
    id?: string;
}
