import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { MatCheckboxModule,
        MatChipsModule,
        MatDialogModule,
        MatDialogRef,
        MatFormFieldModule,
        MatSelectModule,
        MatSnackBarModule,
        MAT_DIALOG_DATA} from '@angular/material';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MenuItemType } from '../../enums/menu-item-type.enum';
import { PizzaIngredients } from '../../enums/pizza-ingredients.enum';
import { ICrust, ISauce } from '../../models/pizza-ingredients.model';

import { ConfirmationDialogComponent } from './confirmation-dialog.component';

describe('ConfirmationDialogComponent', () => {
  let component: ConfirmationDialogComponent;
  let fixture: ComponentFixture<ConfirmationDialogComponent>;
  const dialogMock = {
    close: () => { }
    };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [ReactiveFormsModule,
                MatFormFieldModule,
                MatSelectModule,
                BrowserAnimationsModule,
                MatCheckboxModule,
                MatChipsModule,
                MatDialogModule,
                MatSnackBarModule
              ],
      providers: [
        { provide: MatDialogRef, useValue: dialogMock },
        { provide: MAT_DIALOG_DATA, useValue: [] },
        // ...
      ],
      declarations: [ConfirmationDialogComponent]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfirmationDialogComponent);
    component = fixture.componentInstance;
    component.dialogData = [{
      id: 1,
      name: 'Margherita',

      type: MenuItemType.PIZZA,
      imageUrl: '../../../assets/images/margherita.jpg',
      pizzaDetails: {

          cheese: {
              isExtraCheeseRequired: false,
              price: 30
          },
          crust: {size: 'Medium', price: 140},
          toppings: [
              {ingredientName: PizzaIngredients.OLIVES, price: 50},
              {ingredientName: PizzaIngredients.CAPSICUM, price: 20 },
              {ingredientName: PizzaIngredients.MUSHROOM, price: 40}
          ],
          sauce: {name: 'Harrisa', price: 40},
  },
  otherItemDetails: null,
  },
  {
      id: 2,
      type: MenuItemType.DESERT,
      imageUrl: '../../../assets/images/chocolavacake.jpg',
      name: 'Chocolava Cake',

      pizzaDetails: null,
      otherItemDetails: {
          // tslint:disable-next-line:max-line-length
          // tslint:disable-next-line:max-line-length
          description: 'On the outside, our Chocolate Lava Crunch Cake looks like a simple yet delicious mini chocolate cake, lightly sprinkled with powdered sugar for an extra touch of sweetness. Chocolate Lava Crunch Cakes are baked in our pizza ovens to give them a slightly crunchy, chocolatey crust.',
          price: 100
      },
  }];
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should change crust and add crust price when no previous crust is added', () => {
    const crust: ICrust = {size: 'Small', price: 100};
    component.changeCrust(crust);
    expect(component.price).toBe(100);
  });
  it('should change crust, remove previous crust price, add new crust price when previous crust is present', () => {
    const crust1: ICrust = {size: 'Small', price: 100};
    const crust2: ICrust = {size: 'Medium', price: 140};
    component.changeCrust(crust1);
    component.changeCrust(crust2);
    expect(component.price).toBe(140);
  });
  it('should change sauce and add sauce price when no previous sauce is added', () => {
    component.price = 100;
    const sauce: ISauce = {name: 'Medium', price: 50};
    component.changeSauce(sauce);
    expect(component.price).toBe(150);
  });
  it('should change sauce, remove previous sauce price, add new sauce price when previous crust is present', () => {
    component.price = 100;
    const sauce1: ISauce = {name: 'Harrisa', price: 50};
    const sauce2: ISauce = {name: 'Medium', price: 70};
    component.changeSauce(sauce1);
    component.changeSauce(sauce2);
    expect(component.price).toBe(170);
  });
  it('should add topping price when a new topping is selected', () => {
    component.price = 100;
    const ev = {
      source : {
        value : {
          ingredientName : 'Olives',
          price : 50
        }
      },
      selected: true
  };

    component.changeSelected(ev);

    expect(component.price).toBe(150);

});
  it('should remove topping price when a topping is removed', () => {
    component.price = 100;
    const ev = {
      source : {
        value : {
          ingredientName : 'Olives',
          price : 50
        }
      },
      selected: false
  };

    component.changeSelected(ev);
    expect(component.price).toBe(50);

});
  it('should return selected data to menu items component', () => {


  const spy = spyOn(component.dialogRef, 'close').and.callThrough();

  component.dialogForm.controls.selectCrustFormControl.setValue('Medium');
  component.dialogForm.controls.selectSauceFormControl.setValue('Harrisa');

  component.onPlaceOrderClick();
  // tslint:disable-next-line:max-line-length
  expect(spy).toHaveBeenCalledWith({data: {selectedCrust: 'Medium', selectedSauce: 'Harrisa', extraCheese: null, selectedIngredients: [], price: 0 }});

});

});
