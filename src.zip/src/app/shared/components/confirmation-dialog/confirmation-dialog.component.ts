import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatChip } from '@angular/material/chips';
import { MatSnackBar } from '@angular/material/snack-bar';


import { IMenuItems } from '../../models/menu-items.model';
import { ICrust, IPizzaToppingDetailsModel, ISauce } from '../../models/pizza-ingredients.model';

@Component({
  selector: 'app-confirmation-dialog',
  templateUrl: './confirmation-dialog.component.html',
  styleUrls: ['./confirmation-dialog.component.scss']
})
export class ConfirmationDialogComponent implements OnInit {
  public dialogData: any;

  public customizedPizza: boolean = false;
  private selectedItems: IPizzaToppingDetailsModel[] = [];
  private prevCrust: ICrust | null = null;
  private prevSauce: ISauce | null = null;

public selectedData: any;
  public dialogForm: FormGroup;
  public price: number = 0;
  constructor(
    public dialogRef: MatDialogRef<ConfirmationDialogComponent>,
    public readonly formBuilder: FormBuilder,
    private snackBar: MatSnackBar,
    @Inject(MAT_DIALOG_DATA) public data: IMenuItems) {
      this.dialogData = this.data;
      this.dialogForm = this.formBuilder.group({
        selectCrustFormControl: [null, Validators.required],
        selectSauceFormControl: [null, Validators.required],
        extraCheeseFormControl: []
      });
    }

  ngOnInit() {
    if (this.dialogData.menuitem && this.dialogData.menuitem.totalPrice) {
      this.price = this.dialogData.menuitem.totalPrice;
    } else {
      this.price = 0;
    }
  }

  toggleSelection(chip: MatChip) {
    chip.toggleSelected();
 }
  onCancelClick(): void {
    this.dialogRef.close();
  }

  defaultIngredientsSelections(value: string): boolean {
    let selected = false;
    if (!this.dialogData.customizedPizza) {
      this.selectedItems = this.dialogData.menuitem.pizzaDetails.toppings;
      for (const item of this.selectedItems) {
        if (item.ingredientName === value) {
          selected = true;
          break;
        }
      }
    }
    return selected;
  }

  changeCrust(value: ICrust) {
    if (this.prevCrust) {
      this.removeIngredientPrice(this.prevCrust.price);
    }

    this.addIngredientPrice(value.price);
    // after processing, store the new val as the prev val
    this.prevCrust = value;
  }

  changeSauce(value: ISauce) {
    if (this.prevSauce) {
      this.removeIngredientPrice(this.prevSauce.price);
    }

    this.addIngredientPrice(value.price);
    // after processing, store the new val as the prev val
    this.prevSauce = value;
  }

  changeSelected(ev: any) {
    if (ev.source.value !== ' ') {
    if (ev.selected) {
      this.selectedItems.push(ev.source.value.ingredientName);
      this.addIngredientPrice(ev.source.value.price);
    } else {
      const index = this.selectedItems.indexOf(ev.source.value.ingredientName, 0);
      if (index > -1) {
        this.selectedItems.splice(index, 1);
      }
      this.removeIngredientPrice(ev.source.value.price);
    }
  }
  }

  public onPlaceOrderClick(): void {
    const selectedCrust = this.dialogForm.controls.selectCrustFormControl.value;
    const selectedSauce = this.dialogForm.controls.selectSauceFormControl.value;

    const extraCheese = this.dialogForm.controls.extraCheeseFormControl.value;
    this.selectedData = {selectedCrust,  selectedSauce, extraCheese, selectedIngredients: this.selectedItems, price: this.price};
    this.dialogRef.close({ data: this.selectedData });
    this.snackBar.open('Order placed successfully');
  }

  private addIngredientPrice(ingredientPrice: number) {
     this.price += ingredientPrice;
  }

  private removeIngredientPrice(ingredientPrice: number) {
    this.price -= ingredientPrice;
  }

}
