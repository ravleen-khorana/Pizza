
export interface IPizzaToppingDetailsModel {
    ingredientName: string;
    price: number;
}

export interface IPizzaCrustDetailsModel {
    size: string;
    price: number;
}

export interface IPizzaSauceDetailsModel {
    sauceName: string;
    price: number;
}

export interface ICheese {
    isExtraCheeseRequired: boolean;
    price: number;
}
export interface ICrust {
    size: string;
    price: number;
}

export interface ISauce {
    name: string;
    price: number;
}
