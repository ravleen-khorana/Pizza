import { ICheese, ICrust, IPizzaToppingDetailsModel, ISauce } from './pizza-ingredients.model';

export interface IPizzaDetails {
    crust: ICrust;
    toppings: IPizzaToppingDetailsModel[];
    sauce: ISauce;
    cheese: ICheese;
}
