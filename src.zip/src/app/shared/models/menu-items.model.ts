import { OtherItems } from './other-items.model';
import { IPizzaDetails } from './pizza-details.model';

export interface IMenuItems {
    id: number;
    name: string;

    type: string;
    imageUrl: string;
    pizzaDetails: IPizzaDetails;
    otherItemDetails: OtherItems;

    totalPrice?: number;
}

// tslint:disable-next-line:no-namespace
export namespace IMenuItems {
    export function CalculatePrice(menuItem: IMenuItems): number {
        let price = 0;
        if (menuItem.type === 'Pizza') {
            const pizzaDetails = menuItem.pizzaDetails;
            pizzaDetails.toppings.forEach((topping) => {
                price += topping.price;
            });
            price += pizzaDetails.crust.price;
            if (pizzaDetails.cheese.isExtraCheeseRequired) {
                price += pizzaDetails.cheese.price;
            }
        } else {
            price = menuItem.otherItemDetails.price;
        }
        return price;
    }
}
