
export interface OtherItems {
    price: number;
    description: string;
}
