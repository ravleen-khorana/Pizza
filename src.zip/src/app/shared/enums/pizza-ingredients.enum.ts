export const PizzaIngredients = {
    OLIVES: 'Olives',
    CAPSICUM: 'Capsicum',
    COTTAGE_CHEESE: 'Cottage Cheese',
    CORN: 'Corn',
    JALAPENO: 'Jalepano',
    PEPPER: 'Pepper',
    TOMATO: 'Tomato',
    ONION: 'Onion',
    MUSHROOM: 'Mushroom'
};

export const Crust = {
    SMALL: 'Small',
    MEDIUM: 'Medium',
    LARGE: 'Large'
};
