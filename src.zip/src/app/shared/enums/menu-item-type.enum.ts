export enum MenuItemType {
    PIZZA = 'Pizza',
    BEVERAGE = 'Beverage',
    DESERT = 'Desert'
}
