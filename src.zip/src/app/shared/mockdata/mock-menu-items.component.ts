import { MenuItemType } from '../enums/menu-item-type.enum';
import { IMenuItems } from '../models/menu-items.model';
import { Crust, PizzaIngredients } from '../enums/pizza-ingredients.enum';
export const menuItems: IMenuItems[] = [
    {
        id: 1,
        name: 'Margherita',

        type: MenuItemType.PIZZA,
        imageUrl: '../../../assets/images/margherita.jpg',
        pizzaDetails: {

            cheese: {
                isExtraCheeseRequired: false,
                price: 30
            },
            crust: {size: 'Medium', price: 140},
            toppings: [
                {ingredientName: PizzaIngredients.OLIVES, price: 50},
                {ingredientName: PizzaIngredients.CAPSICUM, price: 20 },
                {ingredientName: PizzaIngredients.MUSHROOM, price: 40}
            ],
            sauce: {name: 'Harrisa', price: 40},
    },
    otherItemDetails: null,
    },
    {
        id: 2,
        type: MenuItemType.DESERT,
        imageUrl: '../../../assets/images/chocolavacake.jpg',
        name: 'Chocolava Cake',

        pizzaDetails: null,
        otherItemDetails: {
            // tslint:disable-next-line:max-line-length
            // tslint:disable-next-line:max-line-length
            description: 'On the outside, our Chocolate Lava Crunch Cake looks like a simple yet delicious mini chocolate cake, lightly sprinkled with powdered sugar for an extra touch of sweetness. Chocolate Lava Crunch Cakes are baked in our pizza ovens to give them a slightly crunchy, chocolatey crust.',
            price: 100
        },
    },
    {
        id: 3,
        type: MenuItemType.PIZZA,

        name: 'Farmhouse',

        imageUrl: '../../../assets/images/farmhouse.jpg',
        pizzaDetails: {
            cheese: {
                isExtraCheeseRequired: false,
                price: 30
            },
            crust: {size: 'Small', price: 100},
            toppings: [
                {ingredientName: PizzaIngredients.COTTAGE_CHEESE, price: 40},
                {ingredientName: PizzaIngredients.ONION, price: 20 },
                {ingredientName: PizzaIngredients.JALAPENO, price: 30}
            ],
            sauce: {name: 'Harrisa', price: 40},
    },
    otherItemDetails: null,
    },
    {
        id: 4,
        type: MenuItemType.PIZZA,

        name: '5 Pepper',

        imageUrl: '../../../assets/images/fivepepper.jpg',
        pizzaDetails: {
            cheese: {
                isExtraCheeseRequired: false,
                price: 30
            },
        crust: {size: 'Medium', price: 140},
        toppings: [
            {ingredientName: PizzaIngredients.CORN, price: 40 },
            {ingredientName: PizzaIngredients.TOMATO, price: 20 },
            {ingredientName: PizzaIngredients.ONION, price: 20}
        ],
        sauce: {name: 'Harrisa', price: 40},
    },
    otherItemDetails: null,
    },
    {
        id: 5,
        type: MenuItemType.BEVERAGE,
        imageUrl: '../../../assets/images/coke.jpg',
        pizzaDetails: null,
        name: 'Coke',

    otherItemDetails: {

        description: 'Sparkling and Refreshing Beverage',
        price: 50
    },
    }
];

// export const pizzaIngredients: IPizzaIgredientDetails[] = [
//     {
//         ingredientName: PizzaIngredients.OLIVES,
//         price: 30
//     },
//     {
//         ingredientName: PizzaIngredients.COTTAGE_CHEESE,
//         price: 30
//     },
//     {
//         ingredientName: PizzaIngredients.CAPSICUM,
//         price: 20
//     },
//     {
//         ingredientName: PizzaIngredients.CORN,
//         price: 20
//     },
//     {
//         ingredientName: PizzaIngredients.JALAPENO,
//         price: 30
//     },
//     {
//         ingredientName: PizzaIngredients.PEPPER,
//         price: 30
//     },
//     {
//         ingredientName: PizzaIngredients.TOMATO,
//         price: 20
//     },
//     {
//         ingredientName: PizzaIngredients.ONION,
//         price: 20
//     },
//     {
//         ingredientName: PizzaIngredients.MUSHROOM,
//         price: 30
//     },
// ];

export const CrustType = {
    smallCrust: Crust.SMALL,
    mediumCrust: Crust.MEDIUM,
    largeCrust: Crust.LARGE
};
