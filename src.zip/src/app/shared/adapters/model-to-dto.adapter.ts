import { IMenuDetailsDto } from 'src/app/core/dtos/menu-details.dto';
import { IMenuItems } from '../models/menu-items.model';

export function AdaptMenuItemsToMenuDetailsDtos(menuItems: IMenuItems): IMenuDetailsDto {

    const menuItem: IMenuDetailsDto = {

        id: menuItems.id,
        name: menuItems.name,

        type: menuItems.type,
        imageUrl: menuItems.imageUrl,
        pizzaDetails: menuItems.pizzaDetails,
        // pizzaDetails: {
        //     cheese: menuItems.pizzaDetails.cheese,
        //     toppings: menuItems.pizzaDetails.topping,
        //     crust: menuItems.pizzaDetails.crust,
        //     sauce: menuItems.pizzaDetails.sauce
        // },
        otherItemDetails: menuItems.otherItemDetails
        };

    return menuItem;
    }
