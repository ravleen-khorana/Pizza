import { IMenuDetailsDto } from 'src/app/core/dtos/menu-details.dto';
import { IPizzaCrustDetailsDto, IPizzaSauceDetailsDto, IPizzaToppingDetailsDto } from 'src/app/core/dtos/pizza-ingredients-details.dto';
import { IMenuItems } from '../models/menu-items.model';
import { ICrust, IPizzaToppingDetailsModel, ISauce } from '../models/pizza-ingredients.model';


// tslint:disable-next-line:max-line-length
export function AdaptIPizzaToppingsDtoToIPizzaToppingsModel(pizzaToppingsDetailsDto: IPizzaToppingDetailsDto): IPizzaToppingDetailsModel {
    const pizzaIngredientModel: IPizzaToppingDetailsModel = {
        ingredientName: pizzaToppingsDetailsDto.ingredientName,
        price: pizzaToppingsDetailsDto.price
    };

    return pizzaIngredientModel;
}

export function AdaptMenuDetailsDtoToMenuDetailsModel(menuItems: IMenuDetailsDto): IMenuItems {

    const menuItem: IMenuItems = {

        id: menuItems.id,
        name: menuItems.name,

        type: menuItems.type,
        imageUrl: 'data:image/jpeg;base64,' + menuItems.imageUrl,
        pizzaDetails: menuItems.pizzaDetails,
        // pizzaDetails: {
        //     cheese: menuItems.pizzaDetails.cheese,
        //     toppings: menuItems.pizzaDetails.topping,
        //     crust: menuItems.pizzaDetails.crust,
        //     sauce: menuItems.pizzaDetails.sauce
        // },
        otherItemDetails: menuItems.otherItemDetails
        };

    return menuItem;
    }

export function AdaptCrustsDtoToCrustsModel(crustDto: IPizzaCrustDetailsDto): ICrust {
        const crust: ICrust = {
        size: crustDto.size,
        price: crustDto.price
        };
        return crust;
}

export function AdaptSauceDtoToSauceModel(sauceDto: IPizzaSauceDetailsDto): ISauce {
    const sauce: ISauce = {
        name: sauceDto.name,
        price: sauceDto.price
    };
    return sauce;
}
