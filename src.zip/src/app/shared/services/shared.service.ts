import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { IdentityResponse } from 'src/app/core/dtos/IdentityResponse.dto';
import { IMenuDetailsDto } from 'src/app/core/dtos/menu-details.dto';
import { IPizzaCrustDetailsDto, IPizzaSauceDetailsDto, IPizzaToppingDetailsDto } from 'src/app/core/dtos/pizza-ingredients-details.dto';

import { environment } from 'src/environments/environment';
import { AdaptCrustsDtoToCrustsModel,
         AdaptIPizzaToppingsDtoToIPizzaToppingsModel,
         AdaptMenuDetailsDtoToMenuDetailsModel,
         AdaptSauceDtoToSauceModel } from '../adapters/dto-to-model.adapter';
import { AdaptMenuItemsToMenuDetailsDtos } from '../adapters/model-to-dto.adapter';
import { IMenuItems } from '../models/menu-items.model';
import { ICrust, IPizzaToppingDetailsModel, ISauce } from '../models/pizza-ingredients.model';

@Injectable({
    providedIn: 'root'
})

export class SharedService {

    appUrl: string;
    toppingsUrl: string;
    menuDetailsUrl: string;
    crustDetailsUrl: string;
    sauceDetailsUrl: string;
    saveOrderDetailsUrl: string;
    httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json; charset=utf-8'
      })
    };
    public ingredients: string[] = [];

    constructor(private httpClient: HttpClient) {
        this.appUrl = environment.appUrl;
        this.toppingsUrl = 'api/pizzaorder/ingredients';
        this.menuDetailsUrl = 'api/pizzaorder/menuItems';
        this.crustDetailsUrl = 'api/pizzaorder/crustDetails';
        this.sauceDetailsUrl = 'api/pizzaorder/sauceDetails';
        this.saveOrderDetailsUrl = 'api/pizzaorder/saveOrder';
    }

    public getAllMenuItems(): Observable<IMenuItems[]> {
            return this.httpClient.get<[IMenuDetailsDto]>(this.appUrl + this.menuDetailsUrl).
            pipe( map((toppingsDto: IMenuDetailsDto[]) =>  toppingsDto.map(AdaptMenuDetailsDtoToMenuDetailsModel))
            );
    }

    public getAllToppings(): Observable<IPizzaToppingDetailsModel[]> {
        return this.httpClient.get<IPizzaToppingDetailsModel[]>(this.appUrl + this.toppingsUrl)
        .pipe(
        map((toppingsDto: IPizzaToppingDetailsDto[]) => {
            return toppingsDto.map(AdaptIPizzaToppingsDtoToIPizzaToppingsModel);
        }
    ));
    }

    public getAllCrustSizes(): Observable<ICrust[]> {
        return this.httpClient.get<ICrust[]>(this.appUrl + this.crustDetailsUrl)
        .pipe(
            map((crustsDto: IPizzaCrustDetailsDto[]) => {
                return crustsDto.map(AdaptCrustsDtoToCrustsModel);
            }
        ));
    }

    public getAllSauces(): Observable<ISauce[]> {
        return this.httpClient.get<ISauce[]>(this.appUrl + this.sauceDetailsUrl)
        .pipe(
            map((sauceDto: IPizzaSauceDetailsDto[]) => {
                return sauceDto.map(AdaptSauceDtoToSauceModel);
            })
        );
    }

    public saveOrder(menuItem: IMenuItems) {
        return this.httpClient.post<IdentityResponse>
        (this.appUrl + this.saveOrderDetailsUrl, menuItem, this.httpOptions)
        .pipe(
            map((response: IdentityResponse) => {
               const orderId = response.id;

               return orderId;
            })
          ).subscribe();
        }

}
