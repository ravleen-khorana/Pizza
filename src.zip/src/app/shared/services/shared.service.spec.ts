import { HttpClient } from '@angular/common/http';
import { TestBed } from '@angular/core/testing';
import { of } from 'rxjs';
import { IMenuDetailsDto } from 'src/app/core/dtos/menu-details.dto';
import { MenuItemType } from '../enums/menu-item-type.enum';
import { PizzaIngredients } from '../enums/pizza-ingredients.enum';
import { IMenuItems } from '../models/menu-items.model';
import { SharedService } from './shared.service';

fdescribe('SharedService', () => {
    let service: SharedService;
    let httpClientMock: HttpClient;

    const menuItems: IMenuDetailsDto[] = [
        {
            id: 1,
            name: 'Margherita',
            type: MenuItemType.PIZZA,
            imageUrl: '../../../assets/images/margherita.jpg',
            pizzaDetails: {
                cheese: {
                    isExtraCheeseRequired: false,
                    price: 30
                },
                crust: {size: 'Medium', price: 140},
                toppings: [
                    {ingredientName: PizzaIngredients.OLIVES, price: 50},
                    {ingredientName: PizzaIngredients.CAPSICUM, price: 20 },
                    {ingredientName: PizzaIngredients.MUSHROOM, price: 40}
                ],
                sauce: {name: 'Harrisa', price: 40},
        },
        otherItemDetails: null,
        },
        {
            id: 2,
            type: MenuItemType.DESERT,
            imageUrl: '../../../assets/images/chocolavacake.jpg',
            name: 'Chocolava Cake',
            pizzaDetails: null,
            otherItemDetails: {
                // tslint:disable-next-line:max-line-length
                // tslint:disable-next-line:max-line-length
                description: 'On the outside, our Chocolate Lava Crunch Cake looks like a simple yet delicious mini chocolate cake, lightly sprinkled with powdered sugar for an extra touch of sweetness. Chocolate Lava Crunch Cakes are baked in our pizza ovens to give them a slightly crunchy, chocolatey crust.',
                price: 100
            },
        },
        {
            id: 3,
            type: MenuItemType.PIZZA,
            name: 'Farmhouse',
            imageUrl: '../../../assets/images/farmhouse.jpg',
            pizzaDetails: {
                cheese: {
                    isExtraCheeseRequired: false,
                    price: 30
                },
                crust: {size: 'Small', price: 100},
                toppings: [
                    {ingredientName: PizzaIngredients.COTTAGE_CHEESE, price: 40},
                    {ingredientName: PizzaIngredients.ONION, price: 20 },
                    {ingredientName: PizzaIngredients.JALAPENO, price: 30}
                ],
                sauce: {name: 'Harrisa', price: 40},
        },
        otherItemDetails: null,
        },
        {
            id: 4,
            type: MenuItemType.PIZZA,
            name: '5 Pepper',
            imageUrl: '../../../assets/images/fivepepper.jpg',
            pizzaDetails: {
                cheese: {
                    isExtraCheeseRequired: false,
                    price: 30
                },
            crust: {size: 'Medium', price: 140},
            toppings: [
                {ingredientName: PizzaIngredients.CORN, price: 40 },
                {ingredientName: PizzaIngredients.TOMATO, price: 20 },
                {ingredientName: PizzaIngredients.ONION, price: 20}
            ],
            sauce: {name: 'Harrisa', price: 40},
        },
        otherItemDetails: null,
        },
        {
            id: 5,
            type: MenuItemType.BEVERAGE,
            imageUrl: '../../../assets/images/coke.jpg',
            pizzaDetails: null,
            name: 'Coke',
        otherItemDetails: {
            description: 'Sparkling and Refreshing Beverage',
            price: 50
        },
        }
    ];

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [SharedService]
          }).compileComponents();
        });
    it('should be created', (done) => {
        httpClientMock = jasmine.createSpyObj('HttpClient', ['get']);
        (httpClientMock.get as jasmine.Spy).and.returnValue(of([]));
        service = new SharedService(httpClientMock);
        expect(service).toBeDefined();
        done();
    });
    it('should return a result from getMenuItems', (done) => {
        httpClientMock = jasmine.createSpyObj('HttpClient', ['get']);

        (httpClientMock.get as jasmine.Spy).and.returnValue(of([menuItems]));
        let isEmitted = false;
        service.getAllMenuItems().subscribe((menuItem) => {
          isEmitted = true;
          expect(menuItem[0].id).toEqual(1);
          done();
        });
        expect(isEmitted).toBeTruthy();
      });
});
