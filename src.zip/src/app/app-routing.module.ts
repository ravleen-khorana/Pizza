import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MenuItemsComponent } from './menu-items/menu-items.component';


export const routes: Routes = [
 {path: '', redirectTo: 'menuitems', pathMatch: 'full'},
 // {path: 'menuitems', loadChildren: './menu-items/menu-items.module#MenuItemsModule'}
{path: 'menuitems', loadChildren: () => import('./menu-items/menu-items.module').then(m => m.MenuItemsModule)
}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
