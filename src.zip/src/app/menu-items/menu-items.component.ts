import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Observable } from 'rxjs';
import { ConfirmationDialogComponent } from '../shared/components/confirmation-dialog/confirmation-dialog.component';
import { IMenuItems } from '../shared/models/menu-items.model';
import { ICrust, IPizzaToppingDetailsModel, ISauce } from '../shared/models/pizza-ingredients.model';
import { SharedService } from '../shared/services/shared.service';

@Component({
  selector: 'app-menu-items',
  templateUrl: './menu-items.component.html',
  styleUrls: ['./menu-items.component.scss']
})
export class MenuItemsComponent implements OnInit {

  constructor(public dialog: MatDialog, private readonly sharedService: SharedService) { }
public items$!: Observable<IMenuItems[]>;
public allToppings!: IPizzaToppingDetailsModel[];
public allCrusts!: ICrust[];

public allSauces!: ISauce[];

public price!: number;
public menuItem!: IMenuItems[];
// public menuItem = menuItems;

   async ngOnInit() {
    await this.getMenuItems();
    await this.getAllToppings();
    await this.getAllCrustSizes();
    await this.getAllSauces();

    // this.items$ = this.sharedService.getAllMenuItems();
    // this.items$.subscribe((value) => this.menuItems = value);
    // tslint:disable-next-line:no-shadowed-variable
    this.getItemPrice();
  }

  public onPlaceOrderClick(menuItem: IMenuItems) {
    this.placeOrder(menuItem);
  }
  public onPizzaCustomizeClick(menuItem: IMenuItems | null, isNewPizza: boolean): void {
    const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
      height: 'auto',
      width: '70%',
      data: {
        menuitem: menuItem,
        allToppings: this.allToppings,
        allCrusts: this.allCrusts,
        allSauces: this.allSauces,
        customizedPizza: isNewPizza
      }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.placeOrder(result.data);
        console.log(result.data);
      }
    });
  }

  private placeOrder(menuItem: IMenuItems) {
    this.sharedService.saveOrder(menuItem);
  }

  private async getAllToppings() {
   this.allToppings = await this.sharedService.getAllToppings().toPromise();
  }

  private async getAllCrustSizes() {
    this.allCrusts = await this.sharedService.getAllCrustSizes().toPromise();
  }

  private async getAllSauces() {
    this.allSauces = await this.sharedService.getAllSauces().toPromise();
  }

  private async getMenuItems() {
     this.menuItem = await this.sharedService.getAllMenuItems().toPromise();
  }

  private getItemPrice() {
    this.menuItem.forEach((menuitem) => {
      menuitem.totalPrice = IMenuItems.CalculatePrice(menuitem);
     });
 }
}
