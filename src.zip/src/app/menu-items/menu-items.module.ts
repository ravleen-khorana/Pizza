import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { MatCardModule} from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatToolbarModule } from '@angular/material/toolbar';

import { RouterModule, Routes } from '@angular/router';
import { MenuItemsComponent } from './menu-items.component';

const routes: Routes = [{
    path: '',
    component: MenuItemsComponent
}];

@NgModule({
    declarations: [MenuItemsComponent],
    imports: [
        RouterModule.forChild(routes),
        MatToolbarModule,
        CommonModule,

        MatCardModule,
        MatFormFieldModule,
    // FormsModule,
        MatIconModule,
        // MatToolbarModule,
        // MatCardModule,
        // FlexLayoutModule
    ],
    providers: []
})

export class MenuItemsModule {
}

