﻿using Domino_Pizzeria.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Domino_Pizzeria.Interfaces.Repositories
{
    public interface IPizzaTypeRepository
    {
        List<PizzaIngredients> GetAllIngredients();
        List<PizzaDetails> GetPizzaDetails();
        List<MenuItems> GetMenuItems();
        List<Crust> GetAllCrusts();
        List<Sauces> GetAllSauces();
    }
}
