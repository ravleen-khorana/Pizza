﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Domino_Pizzeria.Models
{
    public class OtherItemDetails
    {
        public string Description { get; set; }
        public int Price { get; set; }
    }
}
