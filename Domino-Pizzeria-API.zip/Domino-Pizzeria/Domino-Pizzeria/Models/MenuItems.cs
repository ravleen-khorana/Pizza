﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Domino_Pizzeria.Models
{
    public class MenuItems
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Type { get; set; }
        public byte[] ImageUrl { get; set; }
        public PizzaDetails PizzaDetails { get; set; }
        public OtherItemDetails OtherItemDetails { get; set; }
    }
}
