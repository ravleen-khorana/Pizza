﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Domino_Pizzeria.Models
{
    public class PizzaDetails
    {
        public Crust Crust { get; set; }
        public PizzaIngredients[] Toppings { get; set; }
        public Sauces Sauce { get; set; }
        public Cheese Cheese { get; set; }
    }
}
