﻿using Domino_Pizzeria.Interfaces.Repositories;
using Domino_Pizzeria.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Domino_Pizzeria.Repositories
{
    

        public class PizzaTypeRepository : IPizzaTypeRepository

        {

            public List<PizzaIngredients> GetAllIngredients()

            {

                List<PizzaIngredients> ingredients = new List<PizzaIngredients>

            {

                new PizzaIngredients{ IngredientName = "Olives", Price=10},

                new PizzaIngredients{IngredientName = "Capsicum", Price = 20},

                new PizzaIngredients{IngredientName = "Cottage Cheese", Price = 30},

                new PizzaIngredients{IngredientName = "Corn", Price = 40},

                new PizzaIngredients{IngredientName = "Jalepano", Price = 50},

                new PizzaIngredients{IngredientName = "Pepper", Price = 60},

                new PizzaIngredients{IngredientName = "Tomato", Price = 70},

                new PizzaIngredients{IngredientName = "Onion", Price = 80},

                new PizzaIngredients{IngredientName = "Mushroom", Price = 90},

            };



                return ingredients;

            }



            public List<PizzaDetails> GetPizzaDetails()

            {



                var pizzaDeatisl = new List<PizzaDetails>

           {

                new PizzaDetails

                {

                    Crust =new Crust

                    {

                        Id = 1,Size = "Small",Price = 100

                    },

                    Sauce=new Sauces

                    {

                        Name="Harrisa",

                        Price=10

                    },

                    Toppings = new PizzaIngredients[]

                    {

                         new PizzaIngredients{ IngredientName = "Olives", Price=10},

                         new PizzaIngredients{IngredientName = "Capsicum", Price = 20},

                         new PizzaIngredients{IngredientName = "Cottage Cheese", Price = 30},

                         new PizzaIngredients{IngredientName = "Corn", Price = 40},

                    },

                    Cheese = new Cheese

                    {

                        IsExtraCheeseRequired = false,

                        Price=0

                    }

                },

                new PizzaDetails

                {

                    Crust =new Crust

                    {

                        Id = 1,Size = "Medium",Price = 20

                    },

                    Sauce=new Sauces

                    {

                        Name="Barbeque",

                        Price=20

                    },

                    Toppings = new PizzaIngredients[]

                    {

                         new PizzaIngredients{IngredientName = "Jalepano", Price = 50},

                         new PizzaIngredients{IngredientName = "Pepper", Price = 60},

                         new PizzaIngredients{IngredientName = "Tomato", Price = 70},

                    },

                    Cheese = new Cheese

                    {

                        IsExtraCheeseRequired = true,

                        Price=10

                    }

                }

            };



                return pizzaDeatisl;

            }



            public List<MenuItems> GetMenuItems()

            {

                var menuItems = new List<MenuItems>

            {

            new MenuItems {

                Id = 1,

                ImageUrl = System.IO.File.ReadAllBytes(@"C:\Users\hp\Downloads\farmhouse1.jpg"),

                Type = "Pizza",

                Name ="Peppy Paneer",



                PizzaDetails =   new PizzaDetails

                {

                    Crust =new Crust

                    {

                        Id = 1,Size = "Small",Price = 100

                    },

                    Sauce=new Sauces
                    {

                        Name="Harrisa",

                        Price=10

                    },

                    Toppings = new PizzaIngredients[]

                    {

                         new PizzaIngredients{ IngredientName = "Olives", Price=10},

                         new PizzaIngredients{IngredientName = "Capsicum", Price = 20}

                    },

                    Cheese = new Cheese

                    {

                        IsExtraCheeseRequired = false,

                        Price=0

                    }

                },

                OtherItemDetails = null

            },

            new MenuItems

            {

                Id = 2,

                ImageUrl = System.IO.File.ReadAllBytes(@"C:\Users\hp\Downloads\margherita.jpg"),

                Type = "Pizza",

                Name ="Farmhouse",

                PizzaDetails = new PizzaDetails

                {

                    Crust =new Crust

                    {

                        Id = 1, Size = "Medium",Price = 140

                    },

                    Sauce=new Sauces

                    {

                        Name="Barbeque",

                        Price=20

                    },

                    Toppings = new PizzaIngredients[]

                    {

                         new PizzaIngredients{IngredientName = "Jalepano", Price = 50},

                         new PizzaIngredients{IngredientName = "Pepper", Price = 60},

                    },

                    Cheese = new Cheese

                    {

                        IsExtraCheeseRequired = true,

                        Price=50

                    }

                },



                OtherItemDetails = null

            },

            new MenuItems

            {

                 Id = 3,

                Name ="Chocolava Cake",

                ImageUrl = System.IO.File.ReadAllBytes(@"C:\Users\hp\Downloads\chocolavacake.jpg"),

                Type = "Desert",

                PizzaDetails = null,

                OtherItemDetails = new OtherItemDetails

                {

                    Description = "Some description",

                    Price = 80

                }

            },

            new MenuItems

            {

                 Id = 4,

                Name ="Cool Water",

                ImageUrl = System.IO.File.ReadAllBytes(@"C:\Users\hp\Downloads\beverage.jpg"),

                Type = "Beverage",

                PizzaDetails = null,

                OtherItemDetails = new OtherItemDetails

                {

                    Description = "Some description",

                    Price = 50

                }

            }

           };

                return menuItems;



            }



            public List<Crust> GetAllCrusts()

            {

                var crusts = new List<Crust>

            {

                new Crust

                {

                    Id=1,

                    Size="Small",

                    Price=100

                },

                new Crust

                {

                    Id=2,

                    Size="Medium",

                    Price=140,

                },

                new Crust

                {

                    Id=3,

                    Size="Large",

                    Price=180

                }

            };

                return crusts;

            }



            public List<Sauces> GetAllSauces()

            {

                var sauces = new List<Sauces>

            {

                new Sauces

                {

                    Name="Harissa",

                    Price=50

                },

                new Sauces

                {

                    Name="Barbeque",

                    Price=50

                },

                new Sauces

                {

                    Name = "Marinara",

                    Price = 60

                },

                new Sauces

                {

                    Name = "Pesto",

                    Price = 60

                }

            };

                return sauces;

            }

        }

    }