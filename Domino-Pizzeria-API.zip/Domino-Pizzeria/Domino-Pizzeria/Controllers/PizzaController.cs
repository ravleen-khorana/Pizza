﻿using Domino_Pizzeria.Interfaces.Repositories;
using Domino_Pizzeria.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace Domino_Pizzeria.Controllers
{
    [Route("api/pizzaorder")]

    [ApiController]

    public class PizzaController : ControllerBase

    {

        private readonly IPizzaTypeRepository _pizzaTypeRepository;



        public PizzaController(IPizzaTypeRepository pizzaTypeRepository)

        {

            _pizzaTypeRepository = pizzaTypeRepository;

        }



        [HttpGet("ingredients")]

        public ActionResult GetAllIngredients()

        {

            var ingredients = _pizzaTypeRepository.GetAllIngredients();



            return Ok(ingredients);

        }



        [HttpGet("menuItems")]

        public ActionResult GetMenuItems()

        {

            var menuItems = _pizzaTypeRepository.GetMenuItems();

            return Ok(menuItems);

        }



        [HttpGet("crustDetails")]

        public ActionResult GetCrusts()

        {

            var crusts = _pizzaTypeRepository.GetAllCrusts();

            return Ok(crusts);

        }



        [HttpGet("sauceDetails")]

        public IActionResult GetSauces()

        {

            var sauces = _pizzaTypeRepository.GetAllSauces();

            return Ok(sauces);

        }



        //[HttpPost("saveOrder")]

        //public ActionResult PostData([FromBody] MenuItems model)

        //{

        //    var dir = @"C:\temp\myfiles";  // folder location

        //    if (!Directory.Exists(dir))  // if it doesn't exist, create

        //        Directory.CreateDirectory(dir);

        //    string fileName = model.Name + ".json";

        //    string fullPath = System.IO.Path.Combine(dir, fileName);

        //    string json = JsonConvert.SerializeObject(model);

        //    System.IO.File.WriteAllText(fullPath, json);

        //    return Created("http://url/to/your/new/file", model);

        //}

        [HttpPost("saveOrder")]



        // [HttpPost("OrderPizza")]

        public ActionResult PostData([FromBody] MenuItems model)

        {



            var dir = @"C:\temp\ravleen";  // folder location

            if (!Directory.Exists(dir))  // if it doesn't exist, create

                Directory.CreateDirectory(dir);

            string time = (System.DateTime.Now).Second.ToString();

            string fileName = time + ".json";

            string fullPath = System.IO.Path.Combine(dir, fileName);

            string json = JsonConvert.SerializeObject(model);

            System.IO.File.WriteAllText(fullPath, json);

            return Created("http://url/to/your/new/file", model);

        }









    }
}
